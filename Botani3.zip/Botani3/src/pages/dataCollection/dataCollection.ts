import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { AlertController, PopoverController } from 'ionic-angular'
import { DataParams } from '../map/map';
import { Chart } from 'chart.js';
//import { Tree } from '../map/map'
import { EntryPasser } from '../../providers/entrypasser'
import { ClickBlock } from 'ionic-angular/components/app/click-block';

let barGraphIndex = 0;
let lineGraphIndex = 0;
let lineGraphSegment = [3,3,3,3,3,3,3,3,3,3];
let numBarGraphs = 6;
let numLineGraphs = 10;

//the colors for each of the left and right graphs
let barGraphColors = [
    ['rgba(0, 193, 0, 0.5)','rgba(255, 0, 0, 0.5)'],
    ['rgba(213, 255, 0, 0.5)','rgba(0, 0, 255, 0.5)'],
    ['rgba(54, 162, 235, 0.5)','rgba(255, 137, 0, 0.5)'],
    ['rgba(0, 255, 0, 0.5)','rgba(0, 0, 0, 0.5)'],
    ['rgba(255, 0, 222, 0.5)','rgba(0, 255, 213, 0.5)'],
    ['rgba(255, 0, 0, 0.5)','rgba(0, 0, 255, 0.5)']
]

//the data in each of the graphs
let barGraphData = [[50,50],[50,50],[50,50],[50,50],[50,50],[50,50]];

let lineGraphData = [0,180,710,2200,5200,10000];

let lineGraphDataToSend = ['0','1 to 3', '3 to 10','11 to 100','101 to 1,000', '1,001 to 10,000', ' > 10,000'];

//labels for each graph
let barGraphLabels = [
  ['Opened','Not Opened'],
  ['Used','Not Used'],
  ['Full','Not Full'],
  ['Green','Not Green'],
  ['Opened','Not Opened'],
  ['Ripe','Not Ripe']
];

//the titles for each graph
let barGraphTitles = [
  'Open Pollen Cones',
  'Canopy Space Used',
  'Full-Sized Leaves',
  'Colored Leaves',
  'Open Flowers',
  'Ripe Fruit'
];

let lineGraphTitles = [
'Breaking Needle Buds',
'Young Needles',
'Fresh Pollen Cones',
'Unripe Seed Cones',
'Ripe Seed Cones',
'Dropped Seed Cones',
'Breaking Lead Buds',
'Flower Buds',
'Fruits',
'Dropped Fruits'
]

@IonicPage()
@Component({
  selector: 'page-graph',
  templateUrl: 'dataCollection.html'
})
 export class Graphs {
  //each of the view children for bar graphs in the html file
  @ViewChild('openPollenCones') openPollenCones;
  @ViewChild('unfoldingLeaves') unfoldingLeaves;
  @ViewChild('fullSizedLeaves') fullSizedLeaves;
  @ViewChild('coloredLeaves') coloredLeaves;
  @ViewChild('openedFlowers') openedFlowers;
  @ViewChild('ripeFruits') ripeFruits;

  //each of the view children for line graphs
  @ViewChild('breakingNeedleBuds') breakingNeedleBuds;
  @ViewChild('youngNeedles') youngNeedles;
  @ViewChild('freshPollenCones') freshPollenCones;
  @ViewChild('unripeSeedCones') unripeSeedCones;
  @ViewChild('ripeSeedCones') ripeSeedCones;
  @ViewChild('droppedSeedCones') droppedSeedCones;
  @ViewChild('breakingLeafBuds') breakingLeafBuds;
  @ViewChild('flowerBuds') flowerBuds;
  @ViewChild('fruits') fruits;
  @ViewChild('droppedFruits') droppedFruits;

  //these get set to true when they're relevant
  showOpenPollenCones: boolean = true;
  showUnfoldingLeaves: boolean = false;
  showFullSizedLeaves: boolean = false;
  showColoredLeaves: boolean = false;
  showOpenedFlowers: boolean = false;
  showRipeFruits: boolean = false;

  showNumberOfBreakingNeedleBuds: boolean = false;
  showNumberOfYoungNeedles: boolean = false;
  showNumberOfFreshPollenCones: boolean = false;
  showNumberOfUnripeSeedCones: boolean = false;
  showNumberOfRipeSeedCones: boolean = false;
  showNumberOfDroppedSeedCones: boolean = false;
  showNumberOfBreakingLeafBuds: boolean = false;
  showNumberOfFlowerBuds: boolean = false;
  showNumberOfFruits: boolean = false;
  showNumberOfDroppedFruits: boolean = false;

  //starting values for the sliders
  openPollenConesValue: number = 50;
  unfoldingLeavesValue: number = 50;
  fullSizedLeavesValue: number = 50;
  coloredLeavesValue: number = 50;
  openedFlowersValue: number = 50;
  ripeFruitsValue: number = 50;

  breakingNeedleBudsValue: number = 3;
  youngNeedlesValue: number = 3;
  freshPollenConesValue: number = 3;
  unripeSeedConesValue: number = 3;
  ripeSeedConesValue: number = 3;
  droppedSeedConesValue: number = 3;
  breakingLeafBudsValue: number = 3;
  flowerBudsValue: number = 3;
  fruitsValue: number = 3;
  droppedFruitsValue: number = 3;

  LineGraphSendValues: string[] = [];
  BarGraphSendValues: string [] = [];

  barChart: any; //array of barcharts
  lineChart: any; //array of linecharts

  constructor(public navCtrl: NavController, public popoverCtrl: PopoverController, navParams: NavParams, private passer : EntryPasser, private alert : AlertController) {
    console.log("made it here")
      this.barChart = [null,null,null,null,null,null]; //initialize an array of bar charts
      this.lineChart = [null,null,null,null,null,null,null,null,null,null];
      this.initLinegraphSendValues();
      this.initBargraphSendValues();
      this.initBools(navParams.get("params"));
      //this.lineChart = new Linegraphs();
  }

  initBools(params : DataParams)
  {
    if(params.falling)
    {
        this.showColoredLeaves = true;
        this.showFullSizedLeaves = true;
        this.showUnfoldingLeaves = true;
    }
    if(params.pinecone)
    {
        this.showOpenPollenCones = true;
        this.showNumberOfBreakingNeedleBuds = true;
    }
    this.showRipeFruits = params.fruiting;
    this.showOpenedFlowers = params.flowering;
  }

  initLinegraphSendValues(){
      for(let i = 0; i < numLineGraphs; i++){
          this.LineGraphSendValues[i] = lineGraphDataToSend[3];
      }
  }

  initBargraphSendValues(){
    for(let i = 0; i < numBarGraphs; i++){
        this.BarGraphSendValues[i] = '50';
    }
  }

  collectData()
  {
    let entry = {data : "passed"};
    //this.passer.getEntry(entry)
    this.presentPoints();
    this.navCtrl.pop();
  }

  presentPoints()
  {
    let alert = this.alert.create(
      {
        title : "Data sent!",
        subTitle : "You earned 1000 drops",
        buttons : ["Continue"]
      }
    );
    alert.present();
  }

  ionViewDidLoad(){
    for(barGraphIndex = 0; barGraphIndex < numBarGraphs; barGraphIndex++){
      this.barChart[barGraphIndex] = this.getBarChart(); //load each graph into the view
    }
    for(lineGraphIndex = 0; lineGraphIndex < numLineGraphs; lineGraphIndex++){
        this.lineChart[lineGraphIndex]= this.getLineChart();
    }
  }

/*
draws the graph
*/
getChart(context, type, data, options?){
  return new Chart(context, {
      type: type,
      data: data,
      options: options
  });
}

/*
sets the fields and options for each bar graph
*/
getBarChart(){
  let data = 
  {
      scaleStartValue : 0,
      labels: barGraphLabels[barGraphIndex],
      datasets: [{
          label: 'Percentage of ' + barGraphTitles[barGraphIndex],
          data: barGraphData[barGraphIndex],
          backgroundColor: barGraphColors[barGraphIndex]
      }]
  }

  let options = 
  {
      title:{
          display: true,
          text: 'Percentage of ' + barGraphTitles[barGraphIndex],
          fontSize:20
      },
      legend:{
          display: false
      },
      tooltips: {
          enabled: false
      },
      scales: {
          yAxes: [{
              gridLines: {
                  color: "rgba(0, 0, 0, 0)",
              },
              ticks: {
                  beginAtZero: true,
                  min:0,
                  max:100,
                  stepSize:20,
                  tickThickness: 0
              }
          }],
          xAxes: [{
              gridLines: {
                  color: "rgba(0, 0, 0, 0)",
              }
          }]
      }
  }
    if((barGraphIndex === 0) && this.showOpenPollenCones)
        return this.getChart(this.openPollenCones.nativeElement,"bar", data, options);
    else if((barGraphIndex === 1) && this.showUnfoldingLeaves)
        return this.getChart(this.unfoldingLeaves.nativeElement,"bar", data, options);
    else if((barGraphIndex === 2) && this.showFullSizedLeaves)
        return this.getChart(this.fullSizedLeaves.nativeElement,"bar", data, options);
    else if((barGraphIndex === 3) && this.showColoredLeaves)
        return this.getChart(this.coloredLeaves.nativeElement,"bar", data, options);
    else if((barGraphIndex === 4) && this.showOpenedFlowers)
        return this.getChart(this.openedFlowers.nativeElement,"bar", data, options);
    else if((barGraphIndex === 5) && this.showRipeFruits)
        return this.getChart(this.ripeFruits.nativeElement,"bar", data, options);
}

getLineChart(){
  let data = {
      labels: [' ', ' ', ' ', ' ', ' ', ' '],
      datasets: [{
          label: 'Number of ' + lineGraphTitles[lineGraphIndex],
          backgroundColor: '#87E6BF',
          data: this.getExponentialData(lineGraphSegment[lineGraphIndex])
      }]
  }

  let options = {
      title:{
          display: true,
          text: 'Number of ' + lineGraphTitles[lineGraphIndex],
          fontSize:20
      },
      scales:{
          yAxes: [{
              type: 'linear',
              gridLines: {
                  //color: "rgba(0, 0, 0, 0)",
              },
              ticks:{
                  display: true,
                  min: 0,
                  max: 10000,
                  stepSize: 10000
              }
          }],
          xAxes: [{
              gridLines:{
                  color: "rgba(0, 0, 0, 0)"
              }
          }]
      },
      elements:{
          point:{
              radius: 0
          }
      },
      legend:{
          display: false
      },
      tooltips: {
          enabled: false
      }
  }
  if((lineGraphIndex === 0) && this.showNumberOfBreakingNeedleBuds)
        return this.getChart(this.breakingNeedleBuds.nativeElement,"line",data,options);
    else if((lineGraphIndex === 1) && this.showNumberOfYoungNeedles)
        return this.getChart(this.youngNeedles.nativeElement,"line",data,options);
    else if((lineGraphIndex === 2) && this.showNumberOfFreshPollenCones)
        return this.getChart(this.freshPollenCones.nativeElement,"line",data,options);
    else if((lineGraphIndex === 3) && this.showNumberOfUnripeSeedCones)
        return this.getChart(this.unripeSeedCones.nativeElement,"line",data,options);
    else if((lineGraphIndex === 4) && this.showNumberOfRipeSeedCones)
        return this.getChart(this.ripeSeedCones.nativeElement,"line",data,options);
    else if((lineGraphIndex === 5) && this.showNumberOfDroppedSeedCones)
        return this.getChart(this.droppedSeedCones.nativeElement,"line",data,options);
    else if((lineGraphIndex === 6) && this.showNumberOfBreakingLeafBuds)
        return this.getChart(this.breakingLeafBuds.nativeElement,"line",data,options);
    else if((lineGraphIndex === 7) && this.showNumberOfFlowerBuds)
        return this.getChart(this.flowerBuds.nativeElement,"line",data,options);
    else if((lineGraphIndex === 8) && this.showNumberOfFruits)
        return this.getChart(this.fruits.nativeElement,"line",data,options);
    else if((lineGraphIndex === 9) && this.showNumberOfDroppedFruits)
        return this.getChart(this.droppedFruits.nativeElement,"line",data,options);
}

  //get called when the state of a graph changes, and updates that graph
  redrawBarGraph(i,value){
      barGraphIndex = i;
      barGraphData[barGraphIndex] = [value,100-value];
      this.barChart[barGraphIndex].destroy();
      this.barChart[barGraphIndex] = this.getBarChart();
      this.BarGraphSendValues[barGraphIndex] = `${value}`;
  }

  redrawLineGraph(i,inputSegment){
      lineGraphIndex = i;
      lineGraphSegment[lineGraphIndex] = inputSegment;
      this.lineChart[lineGraphIndex].destroy();
      this.lineChart[lineGraphIndex] = this.getLineChart();
      this.LineGraphSendValues[lineGraphIndex] = lineGraphDataToSend[inputSegment];
  }

  getExponentialData(size){
      let result: number [] = [];
      for(let i = 0; i <= size; i++)
          result[i] = lineGraphData[i];
      
      return result;
  }

  getInfo(myEvent){

    let popover = this.popoverCtrl.create(PopoverPage,{},{cssClass: 'custom-popover'});
    popover.present({
        ev: myEvent
    });
  }
}


// this will be changed to fit the needs of the database
export interface Entry
{
  data : string
}

@Component({
    template:`
    <ion-list>
        <ion-list-header color = "secondary"> Popover </ion-list-header>
        <p ion-item >Here will be info on this data </p>
    </ion-list>
    `
})
export class PopoverPage{
    constructor(public viewCtrl: ViewController){

    }
    close(){
        this.viewCtrl.dismiss();
    }
}
