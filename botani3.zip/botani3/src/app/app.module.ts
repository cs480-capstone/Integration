import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { TreeFactory } from '../providers/treefactory';
import { BotaniMap } from '../pages/map/map';

import { Geolocation } from '@ionic-native/geolocation';
import { HttpModule } from '@angular/http';

import { MyApp } from './app.component';

import { BotaniMapModule } from '../pages/map/map.module';
import { HelpPageModule } from '../pages/help/help.module'
import { DataCollectionModule } from  '../pages/dataCollection/dataCollection.module';
import { EntryPasserProvider } from '../providers/entry-passer/entry-passer';
import { PopoverPage } from '../pages/dataCollection/dataCollection';

@NgModule({
  declarations: [
    MyApp
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    DataCollectionModule,
    HelpPageModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    PopoverPage
  ],
  providers: [
    Geolocation,
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    TreeFactory,
    HttpModule,
    EntryPasserProvider
  ]
})
export class AppModule {}
