npm install ionic@latest
npm install chart.js --save